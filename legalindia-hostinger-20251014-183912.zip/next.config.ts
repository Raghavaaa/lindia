const nextConfig = {
  // Dynamic server functions enabled for API routes
};

export default nextConfig;
